<div align="center">

# 🧠 Face Recognition & Emotion Detection System

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.10%2B-3776AB?style=for-the-badge&logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/TensorFlow-2.x-FF6F00?style=for-the-badge&logo=tensorflow&logoColor=white" />
  <img src="https://img.shields.io/badge/OpenCV-4.x-5C3EE8?style=for-the-badge&logo=opencv&logoColor=white" />
  <img src="https://img.shields.io/badge/DeepFace-Enabled-blueviolet?style=for-the-badge" />
  <img src="https://img.shields.io/badge/FastAPI-REST%20API-009688?style=for-the-badge&logo=fastapi&logoColor=white" />
  <img src="https://img.shields.io/badge/Auth-API%20Key%20%2B%20Rate%20Limit-orange?style=for-the-badge&logo=shield&logoColor=white" />
  <img src="https://img.shields.io/badge/GCS-Cloud%20Storage-4285F4?style=for-the-badge&logo=googlecloud&logoColor=white" />
  <img src="https://img.shields.io/badge/Docker-Ready-2496ED?style=for-the-badge&logo=docker&logoColor=white" />
  <img src="https://img.shields.io/badge/Status-Active-brightgreen?style=for-the-badge" />
  <img src="https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge" />
</p>

<p align="center">
  <b>A production-grade, end-to-end AI pipeline that identifies specific team members and detects real-time emotions from images and video streams — secured, scalable, and cloud-integrated.</b>
</p>

<br/>

</div>

---

## 📌 Table of Contents

- [Overview](#-overview)
- [Features](#-features)
- [System Architecture](#-system-architecture)
- [How It Works](#-how-it-works)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [VS Code Setup](#-vs-code-setup)
- [Environment Configuration](#-environment-configuration)
- [Authentication & Authorization](#-authentication--authorization)
- [Usage](#-usage)
- [API Reference](#-api-reference)
- [Debugging in VS Code](#-debugging-in-vs-code)
- [Pipeline → Notebook Mapping](#-pipeline--notebook-mapping)
- [Security Architecture](#-security-architecture)
- [Logging](#-logging)
- [Frontend](#-frontend)
- [Future Improvements](#-future-improvements)
- [Contributing](#-contributing)
- [Contributors](#-contributors)
- [License](#-license)

---

## 🔍 Overview

The **Face Recognition & Emotion Detection System** is a production-ready, end-to-end AI pipeline for identifying specific team members and detecting their real-time emotions from images and video streams.

The system uses a **hybrid approach** combining deep learning with classical ML:

1. **Identity Recognition** — FaceNet generates 512-dimensional facial embeddings, which a calibrated SVM classifier maps to known identities. A cosine similarity gate rejects faces that fall below the confidence threshold, gracefully returning `Unknown` rather than a false match.
2. **Emotion Detection** — DeepFace runs a customized `detect_with_calibration()` layer on top of standard emotion inference to smooth fluctuating frame-by-frame predictions and improve real-world accuracy.

All API endpoints are protected by API Key authentication and rate limiting. The full pipeline is cloud-integrated via Google Cloud Storage for both dataset ingestion and model artifact deployment.

---

## ✨ Features

| Feature | Description |
|---|---|
| 🎯 **Real-Time Face Detection** | Live webcam and static image inference using OpenCV with face alignment and normalization |
| 🧬 **FaceNet 512-D Embeddings** | High-precision identity embeddings with L2 normalization and Gaussian noise augmentation |
| 🔬 **Cosine Similarity Gate** | Rejects unknown faces below threshold — no false positives on unseen identities |
| 😄 **Calibrated Emotion Detection** | DeepFace with a custom calibration layer for stable, smoothed emotion predictions |
| 🔄 **7-Stage Modular Pipeline** | Ingest → Preprocess → Extract → Train → Infer → Realtime → Deploy — each stage independently runnable |
| 🔐 **API Key Authentication** | All REST endpoints protected via `X-API-Key` header validation |
| ⚡ **Rate Limiting** | Per-client request throttling via `slowapi` to prevent abuse |
| ☁️ **GCS Integration** | Dataset sync and model artifact upload/download via Google Cloud Storage |
| 💾 **Embedding Cache** | FaceNet embeddings cached locally — re-training the SVM skips re-extraction entirely |
| 🖼️ **Multi-Format Image Support** | Handles JPG, PNG, and HEIC/HEIF formats with a 10MB upload limit |
| 📊 **Structured Logging** | Console, rotating file, and JSON log outputs simultaneously |
| 🐳 **Docker Support** | Fully containerized for consistent production deployment |
| 🧪 **Pytest Test Suite** | Unit tests covering all pipeline stages |
| 🛠️ **VS Code Ready** | Pre-configured interpreter, linting, formatting, and per-pipeline debug launch configs |

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    GCS_IN["☁️ GCS Bucket\nTeamFaces.zip + raf-db.zip"] -->|Pipeline 1: data_ingestion| RAW["📁 data/raw/\nExtracted Images"]
    RAW -->|Pipeline 2: preprocessing| PROC["🧹 data/processed/\nAligned, Validated JPEGs"]
    PROC -->|Pipeline 3: feature_extraction| CACHE["💾 embeddings_cache.pkl\n512-D FaceNet Vectors"]

    CACHE -->|Pipeline 4: training| SVM["🤖 SVM Classifier\nCalibratedSVC · RBF · C=10\n3-fold CV · Confusion Matrix"]
    CACHE -->|Pipeline 4: training| EMO["😊 Emotion Model\nDeepFace + Calibration Layer"]

    SVM -->|Pipeline 7: deployment| GCS_OUT["☁️ GCS Model Registry\n5 Artifact Files"]
    EMO -->|Pipeline 7: deployment| GCS_OUT

    INPUT["📷 Input\nImage / Webcam / base64"] --> GATE["🔐 Auth Layer\nX-API-Key + Rate Limit"]
    GATE -->|Pipeline 5: inference| FACE_REC["models/face_model.py\nFaceRecognizer\n+ Cosine Gate"]
    GATE -->|Pipeline 5: inference| EMO_INF["models/emotion_model.py\ndetect_with_calibration()"]

    FACE_REC --> OUT["🏷️ Identity + Confidence\nor Unknown"]
    EMO_INF --> OUT2["💬 Smoothed Emotion\n+ Confidence"]

    OUT --> RENDER["🖼️ Annotated Output\nBounding Box + Labels"]
    OUT2 --> RENDER

    RENDER -->|Pipeline 6: realtime| CAM["📺 Live Webcam\nq=quit · s=snapshot"]
    RENDER -->|api/app.py| API["🌐 FastAPI Response\n/predict/image · /predict/base64"]
    API -->|Coming soon| FE["🖥️ Live Frontend"]

    style GCS_IN fill:#0d1117,stroke:#58a6ff,color:#c9d1d9
    style GCS_OUT fill:#0d1117,stroke:#f78166,color:#c9d1d9
    style GATE fill:#0d1117,stroke:#f0a500,color:#c9d1d9
    style RENDER fill:#0d1117,stroke:#3fb950,color:#c9d1d9
    style FE fill:#0d1117,stroke:#a371f7,color:#c9d1d9
```

---

## ⚙️ How It Works

### Pipeline 1 — Data Ingestion (`pipelines/data_ingestion.py`)
Checks GCS for a previously saved model. If one exists, it downloads the artifacts and exits early — no training needed. If not, it downloads `TeamFaces.zip` and `raf-db.zip` from the configured bucket and extracts them to `data/raw/`.

### Pipeline 2 — Preprocessing (`pipelines/preprocessing.py`)
Walks `data/raw/TeamFaces/`, validates every image (HEIC conversion, minimum resolution check, face sanity check), and writes clean, aligned JPEGs to `data/processed/`. Corrupted or faceless images are logged and skipped.

### Pipeline 3 — Feature Extraction (`pipelines/feature_extraction.py`)
Passes each processed image through FaceNet to produce a 512-dimensional embedding vector. Embeddings are augmented with Gaussian noise and L2-normalised, then cached to `saved_models/embeddings_cache.pkl`. Subsequent training runs load the cache directly — DeepFace is not re-run.

### Pipeline 4 — Training (`pipelines/training.py`)
Performs a stratified 80/20 train/test split, then fits a `CalibratedClassifierCV(SVC(kernel='rbf', C=10))` with 3-fold cross-validation. Outputs a full classification report and confusion matrix. Saves four model artifact files to `saved_models/`.

### Pipeline 5 — Inference (`pipelines/inference.py`)
Accepts a static image path, base64 string, or file upload. Runs: detect → embed → cosine gate → classify identity → `detect_with_calibration()` for emotion → returns annotated output dict with bounding box coordinates, name, emotion, and confidence scores.

### Pipeline 6 — Real-Time (`pipelines/realtime.py`)
Opens the webcam via OpenCV and runs Pipeline 5 on every frame. Renders live bounding boxes with name + emotion labels. Press `q` to quit, `s` to save a snapshot to `data/output/snapshots/`.

### Pipeline 7 — Deployment (`pipelines/deployment.py`)
Uploads all five model artifacts from `saved_models/` back to the GCS bucket. The next invocation of `python main.py train` will detect the uploaded models and skip training entirely.

---

## 🛠️ Tech Stack

<div align="center">

| Layer | Technology |
|---|---|
| **Language** | Python 3.10+ |
| **Deep Learning** | TensorFlow 2.x, Keras |
| **Face Analysis** | DeepFace, FaceNet (512-D embeddings) |
| **Computer Vision** | OpenCV 4.x, Pillow, pillow-heif |
| **ML Classification** | Scikit-learn — CalibratedClassifierCV, SVC (RBF) |
| **REST API** | FastAPI + Uvicorn |
| **Authentication** | API Key (`X-API-Key` header) |
| **Rate Limiting** | slowapi |
| **Cloud Storage** | Google Cloud Storage (`google-cloud-storage`) |
| **Data Processing** | NumPy, Pandas |
| **Containerization** | Docker |
| **Testing** | Pytest |
| **Environment** | python-dotenv, `.env` config |

</div>

---

## 📁 Project Structure

```
face_emotion_system/
│
├── config/
│   └── settings.py            ← All config values — env-driven, zero hard-coding
│
├── pipelines/                 ← One file per pipeline stage
│   ├── data_ingestion.py      ← PIPELINE 1: GCS smart download (skips if model exists)
│   ├── preprocessing.py       ← PIPELINE 2: HEIC conversion, alignment, validation
│   ├── feature_extraction.py  ← PIPELINE 3: FaceNet embeddings + noise augment + cache
│   ├── training.py            ← PIPELINE 4: CalibratedSVC · 3-fold CV · metrics
│   ├── inference.py           ← PIPELINE 5: Static image / base64 prediction
│   ├── realtime.py            ← PIPELINE 6: Live webcam loop (q=quit, s=snapshot)
│   └── deployment.py          ← PIPELINE 7: Upload 5 artifacts to GCS
│
├── models/
│   ├── face_model.py          ← FaceRecognizer: SVM + cosine similarity gate
│   └── emotion_model.py       ← infer_emotion(), detect_with_calibration()
│
├── storage/
│   └── gcs_storage.py         ← GCS upload / download abstraction
│
├── utils/
│   ├── logger.py              ← Console + rotating file + JSON log outputs
│   └── image_utils.py         ← Load / resize / annotate / HEIC helpers
│
├── api/
│   └── app.py                 ← FastAPI server — auth-protected, rate-limited
│
├── tests/
│   └── test_pipelines.py      ← Pytest unit tests per pipeline stage
│
├── .vscode/
│   ├── settings.json          ← Python interpreter, lint, format, test config
│   └── launch.json            ← One debug launch config per pipeline / mode
│
├── main.py                    ← Master CLI: train · api · realtime · infer · status
├── requirements.txt
├── Dockerfile
├── .env.example               ← Copy → .env and fill in values
└── .gitignore                 ← Excludes: .env · secrets/ · saved_models/ · data/
```

---

## 🖥️ VS Code Setup

### Step 1 — Clone and open the project

```bash
git clone https://github.com/your-org/face-emotion-system.git
# File → Open Folder → select face_emotion_system/
```

### Step 2 — Create a virtual environment

Open the integrated terminal (`Ctrl+`` ` ``):

```bash
# macOS / Linux
python3 -m venv .venv
source .venv/bin/activate

# Windows
python -m venv .venv
.venv\Scripts\activate
```

VS Code will detect `.venv` and prompt you to select it as the interpreter. Click **Yes**, or use `Ctrl+Shift+P` → **Python: Select Interpreter** → pick `.venv/bin/python`.

### Step 3 — Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

> **Apple Silicon (M1/M2/M3):** Replace `tensorflow` with `tensorflow-macos` in `requirements.txt`.

### Step 4 — Verify setup

```bash
python main.py status
```

All model files will show ❌ — this is expected before training.

---

## 🔐 Environment Configuration

Copy the example file and fill in your values. **Never commit `.env` to git.**

```bash
cp .env.example .env
```

```ini
# .env.example

# Google Cloud Storage
GCS_PROJECT_ID=your-gcp-project-id
GCS_BUCKET_NAME=your-bucket-name
GCS_KEY_PATH=secrets/gcs_key.json

# Data paths
DATA_RAW_DIR=data/raw
DATA_PROCESSED_DIR=data/processed
EMBEDDINGS_CACHE=saved_models/embeddings_cache.pkl

# Model output paths
SAVED_MODELS_DIR=saved_models

# Training hyperparameters
SVM_C=10
CV_FOLDS=3
CONFIDENCE_THRESHOLD=0.50

# API server
API_HOST=0.0.0.0
API_PORT=8000

# Authentication
API_KEY_HEADER=X-API-Key
VALID_API_KEYS=key-one,key-two,key-three

# Rate limiting (requests per minute per client)
RATE_LIMIT=60

# Logging
LOG_LEVEL=INFO
```

Place your GCS service-account JSON at `secrets/gcs_key.json`. The `secrets/` directory is in `.gitignore`.

> ⚠️ **Security:** `secrets/` and `.env` are excluded from git. Never commit credentials. See [Security Architecture](#-security-architecture) for full details.

---

## 🔒 Authentication & Authorization

All REST API endpoints require a valid API key. Requests missing the key or supplying an unrecognized value receive a `401 Unauthorized` response immediately — before any model inference runs.

### How to authenticate

Include your API key in the `X-API-Key` request header on every call:

```bash
curl -X POST "http://localhost:8000/predict/image" \
  -H "X-API-Key: your-api-key-here" \
  -F "file=@/path/to/photo.jpg"
```

### Rate limiting

Each API key is subject to a configurable per-minute request limit (default: 60 req/min) enforced by `slowapi`. Clients that exceed the limit receive `429 Too Many Requests` with a `Retry-After` header.

### Endpoint access

| Endpoint | Auth Required | Notes |
|---|---|---|
| `GET /health` | No | Public liveness check |
| `GET /metrics` | Yes | Request count + avg latency |
| `GET /model/info` | Yes | Loaded model metadata |
| `POST /predict/image` | Yes | File upload inference |
| `POST /predict/base64` | Yes | Base64 string inference |

### Managing API keys

API keys are defined in the `VALID_API_KEYS` environment variable as a comma-separated list. To rotate or revoke a key, remove it from `.env` and restart the server — no code changes required.

> 🔐 **Best practice:** Use a secrets manager (GCP Secret Manager, AWS Secrets Manager, HashiCorp Vault) for API key storage in production rather than `.env` files.

---

## 🎮 Usage

All pipeline stages are orchestrated through `main.py`.

### Run the full training pipeline

```bash
python main.py train
```

| Stage | What happens |
|---|---|
| **1. Data Ingestion** | Checks GCS for a saved model. If found, downloads and exits early. Otherwise downloads `TeamFaces.zip` + `raf-db.zip`. |
| **2. Preprocessing** | Walks `data/raw/TeamFaces/`, converts HEIC, validates, resizes, writes to `data/processed/`. |
| **3. Feature Extraction** | Extracts 512-D FaceNet embeddings with noise augmentation. Caches to `embeddings_cache.pkl`. |
| **4. Training** | Stratified 80/20 split → CalibratedSVC(RBF, C=10) → 3-fold CV → report + confusion matrix. |
| **5. Deployment** | Uploads all 5 model artifacts to GCS. Subsequent runs load from GCS instead of re-training. |

Force re-training even if a saved model exists:

```bash
python main.py train --force-retrain --skip-deploy
```

### Run inference on a static image

```bash
python main.py infer --image path/to/group_photo.jpg
```

Outputs:
- Annotated image → `data/output/<name>_detected.jpg`
- JSON results → `data/output/<name>_results.json`
- Console log with per-face: name, emotion, confidence

### Start the real-time webcam loop

```bash
python main.py realtime
```

Controls: `q` — quit · `s` — save snapshot to `data/output/snapshots/`

### Start the REST API server

```bash
python main.py api
# or directly:
uvicorn api.app:app --reload --host 0.0.0.0 --port 8000
```

Swagger UI available at `http://localhost:8000/docs`.

### Check system status

```bash
python main.py status
```

### Run tests

```bash
pytest tests/ -v
```

### Docker (production)

```bash
# Build
docker build -t face-emotion-api .

# Run
docker run -p 8000:8000 \
  --env-file .env \
  -v $(pwd)/secrets:/app/secrets:ro \
  -v $(pwd)/saved_models:/app/saved_models \
  face-emotion-api
```

---

## 🌐 API Reference

> 🔐 All endpoints except `GET /health` require the `X-API-Key` header.

Interactive Swagger docs with auth support: `http://localhost:8000/docs`

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/health` | No | Liveness check |
| `GET` | `/model/info` | Yes | Loaded model metadata |
| `GET` | `/metrics` | Yes | Request count, avg latency |
| `POST` | `/predict/image` | Yes | Upload JPEG/PNG/HEIC → identity + emotion |
| `POST` | `/predict/base64` | Yes | Send base64 image string → identity + emotion |

**File upload — example request:**

```bash
curl -X POST "http://localhost:8000/predict/image" \
  -H "X-API-Key: your-api-key-here" \
  -H "accept: application/json" \
  -F "file=@/path/to/photo.jpg"
```

**Base64 — example request:**

```bash
curl -X POST "http://localhost:8000/predict/base64" \
  -H "X-API-Key: your-api-key-here" \
  -H "Content-Type: application/json" \
  -d '{"image": "<base64-encoded-string>"}'
```

**Example response:**

```json
{
  "faces": [
    {
      "name": "Alice",
      "face_confidence": 0.94,
      "emotion": "happy",
      "emotion_confidence": 0.87,
      "bounding_box": { "x": 120, "y": 45, "w": 180, "h": 200 }
    }
  ],
  "total_faces": 1,
  "processing_time_ms": 143
}
```

**Error responses:**

```json
{ "detail": "Invalid or missing API key" }     // 401
{ "detail": "Rate limit exceeded" }             // 429
{ "detail": "File too large (max 10MB)" }       // 413
{ "detail": "No face detected in image" }       // 422
```

---

## 🛠️ Debugging in VS Code

`.vscode/launch.json` includes a pre-configured debug config for every pipeline stage and mode.

1. Open the **Run & Debug** panel (`Ctrl+Shift+D`)
2. Select a config from the dropdown — e.g. `▶ Train (full pipeline)`
3. Press `F5`

Set breakpoints in any pipeline file and the debugger stops there with full variable inspection.

---

## 🗺️ Pipeline → Notebook Mapping

If you are migrating from the original Jupyter notebook, here is the exact mapping:

| Original Notebook Cell | Production File |
|---|---|
| CELL 1 — pip install | `requirements.txt` |
| CELL 2 — GCS auth + download | `pipelines/data_ingestion.py` + `storage/gcs_storage.py` |
| CELL 3 — imports | Distributed across each module |
| CELL 4 — shared config + `infer_emotion()` | `config/settings.py` + `models/emotion_model.py` |
| CELL 5 — `detect_with_calibration()` | `models/emotion_model.py` |
| CELL 6 — train SVM | `pipelines/preprocessing.py` + `pipelines/feature_extraction.py` + `pipelines/training.py` |
| CELL 6b — upload model | `pipelines/deployment.py` |
| CELL 7 — group photo inference | `pipelines/inference.py` |
| CELL 8 — webcam loop | `pipelines/realtime.py` |

---

## 🔑 Security Architecture

### What was fixed

The original notebook contained a **hard-coded GCS private key** embedded directly in Python source — a critical vulnerability that allows anyone with read access to impersonate the service account.

### How this project fixes it

1. The service account key is stored as a JSON file in `secrets/` which is excluded from git via `.gitignore`.
2. Only the **file path** is read from an environment variable (`GCS_KEY_PATH`) — the key material never appears in source code.
3. In production environments (Cloud Run, GKE), **Application Default Credentials** are used instead of a key file — no secret files needed at all.
4. All API keys are stored in environment variables, never hard-coded.
5. The `secrets/` directory and `.env` file are both in `.gitignore` and excluded from Docker image builds via `.dockerignore`.

---

## 📋 Logging

Three log outputs are written simultaneously on every run:

| Output | Format | Purpose |
|---|---|---|
| Console | Coloured, human-readable | Development and local debugging |
| `logs/app.log` | Plain-text, rotating | Ops monitoring and debugging |
| `logs/app.jsonl` | One JSON object per line | Machine ingestion — ELK, Datadog, Cloud Logging |

Log level is controlled by the `LOG_LEVEL` environment variable: `DEBUG` · `INFO` · `WARNING` · `ERROR`.

---

## 🖥️ Frontend

> 🚧 **Coming Soon** — A live web frontend is currently in development and will be released in an upcoming version.

The frontend will connect to this API using authenticated requests and provide a real-time browser-based interface for face recognition and emotion detection — no local setup or CLI required.

---

## 🔭 Future Improvements

- [ ] **Live Frontend** — Browser-based UI for real-time inference via the REST API *(in progress)*
- [ ] **JWT Authentication** — Upgrade from static API keys to short-lived JWT tokens with refresh flow
- [ ] **OAuth2 / SSO** — Google or GitHub login for team environments
- [ ] **FAISS Vector Search** — Replace SVM with approximate nearest-neighbor for 10k+ identity databases
- [ ] **Anti-Spoofing** — Liveness detection to reject photo and screen-based attacks
- [ ] **Multi-Camera Support** — Simultaneous inference across multiple video streams
- [ ] **Age & Gender Estimation** — Additional demographic prediction via DeepFace
- [ ] **Attendance Module** — Auto-log recognized identities with timestamps to a database
- [ ] **MLflow Integration** — Experiment tracking, model versioning, and artifact registry
- [ ] **GPU Acceleration** — CUDA / TensorRT optimization for edge and real-time deployment
- [ ] **Kubernetes Deployment** — Helm chart for scalable cloud-native serving

---

## 🤝 Contributing

Contributions are welcome and appreciated. Here's how to get started:

```bash
# 1. Fork the repository
# 2. Create your feature branch
git checkout -b feature/your-feature-name

# 3. Commit your changes (conventional commits preferred)
git commit -m "feat: add your feature description"

# 4. Push to your branch
git push origin feature/your-feature-name

# 5. Open a Pull Request
```

Please follow the existing code style, add tests for any new pipeline stage or API endpoint, and update this README if you introduce new CLI flags, auth scopes, or configuration keys.

---

## 👥 Contributors

<div align="center">

This project is built and maintained by a team of contributors.

[![Contributors](https://img.shields.io/github/contributors/your-org/face-emotion-system?style=for-the-badge&color=brightgreen)](https://github.com/your-org/face-emotion-system/graphs/contributors)

See the full list on the [GitHub Contributors page](https://github.com/AastikDaryal1/Facial_recognition_and_expression_detection.git).

</div>

---

## 📄 License

This project is licensed under the **MIT License** — see the [LICENSE](LICENSE) file for full details.

---

<div align="center">

⭐ **If this project helped you, consider giving it a star!** ⭐

<br/>

<img src="https://img.shields.io/github/stars/your-org/face-emotion-system?style=social" />
&nbsp;
<img src="https://img.shields.io/github/forks/your-org/face-emotion-system?style=social" />

</div>
